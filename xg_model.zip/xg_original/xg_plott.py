import pickle

import torch
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import GroupShuffleSplit

from model import NeuralNetwork
from config import (
    RANDOM_STATE, TEST_SIZE,
    PREPROCESSED_FILE, SHOT_EVENTS_FILE, FEATURE_META_FILE,
    MODEL_STATE_FILE, SCALER_FILE, PENALTY_XG, MATCH_SEED,
)

# ===========================================================================================================
# Last inn forhåndsprosessert data + rådata
# ===========================================================================================================

preprossessert = pd.read_pickle(PREPROCESSED_FILE) 
shot_events_raw = pd.read_pickle(SHOT_EVENTS_FILE)

with open(FEATURE_META_FILE, "rb") as f: #Henter inn hvilke kolonner som er hva
    feature_meta = pickle.load(f)

num_cols = feature_meta["num_cols"] #Henter inn numeriske kolonner

match_id_full = preprossessert["match_id"] #Alle match-id-er
y_full = preprossessert["goal"] #Alle target-verdier

X_full = preprossessert.drop( #Henter X
    columns=["match_id", "goal", "shot_statsbomb_xg"]
)


# ===========================================================================================================
# Identifiser straffer
# ===========================================================================================================

is_penalty_full = ( #Henter ut kun data som er straffer?
    X_full.get(
        "shot_type_Penalty",
        pd.Series(0.0, index=X_full.index)
    ) == 1.0
)


# ===========================================================================================================
# Finn testsettet
# ===========================================================================================================

X_no_pen = X_full[~is_penalty_full]
y_no_pen = y_full[~is_penalty_full]
match_id_no_pen = match_id_full[~is_penalty_full]

gss_test = GroupShuffleSplit(
    n_splits=1,
    test_size=TEST_SIZE,
    random_state=RANDOM_STATE
)

_, test_idx = next(
    gss_test.split(
        X_no_pen,
        y_no_pen,
        groups=match_id_no_pen
    )
)

test_match_ids = match_id_no_pen.iloc[test_idx].unique()


# ===========================================================================================================
# Velg tilfeldig kamp fra testsettet
# ===========================================================================================================

rng = np.random.default_rng(MATCH_SEED)
selected_match_id = rng.choice(test_match_ids)


# ===========================================================================================================
# Hent ALLE skudd for den valgte kampen
# ===========================================================================================================

match_rows = match_id_full == selected_match_id

X_match = X_full[match_rows].copy()
is_penalty_match = is_penalty_full[match_rows]


# ===========================================================================================================
# Last inn scaler + imputeringsverdier
# ===========================================================================================================

bundle = joblib.load(SCALER_FILE)
scaler = bundle["scaler"]

X_match["gk_dist"] = X_match["gk_dist"].fillna(
    bundle["gk_dist_median"]
)

X_match["gk_angle_dev"] = X_match["gk_angle_dev"].fillna(
    bundle["gk_angle_median"]
)

X_match["dist_nearest_opp_in_cone"] = X_match[
    "dist_nearest_opp_in_cone"
].fillna(
    bundle["no_defender_dist"]
)

X_match.loc[:, num_cols] = scaler.transform(
    X_match[num_cols]
)


# ===========================================================================================================
# Last inn den trente modellen
# ===========================================================================================================

xg_model = NeuralNetwork(
    input_size=X_full.shape[1],
    output_size=1,
    penalty_xg=PENALTY_XG
)

xg_model.load_state_dict(
    torch.load(MODEL_STATE_FILE)
)

xg_model.eval()


# ===========================================================================================================
# Lag prediksjoner
# ===========================================================================================================

X_match_t = torch.tensor(
    X_match.to_numpy(dtype=np.float32)
)

is_penalty_t = torch.tensor(
    is_penalty_match.to_numpy()
)

p_match = xg_model.predict_proba(
    X_match_t,
    is_penalty=is_penalty_t
).numpy().flatten()


# ===========================================================================================================
# Koble prediksjoner tilbake til rådata
# ===========================================================================================================

match = shot_events_raw.loc[X_match.index].copy()

match["predicted_xg"] = p_match

match["goal"] = (
    match["shot_outcome"] == "Goal"
).astype(int)


# ===========================================================================================================
# Finn lagene
# ===========================================================================================================

teams = match["team"].dropna().unique().tolist()

if len(teams) != 2:
    raise ValueError(
        f"Forventet to lag i kamp {selected_match_id}, men fant: {teams}"
    )

team_1, team_2 = teams[0], teams[1]


# ===========================================================================================================
# Predikert xG per minutt
# ===========================================================================================================

xg_by_minute = (
    match
    .groupby(["minute", "team"])["predicted_xg"]
    .sum()
    .unstack(fill_value=0)
)

for team in teams:
    if team not in xg_by_minute.columns:
        xg_by_minute[team] = 0.0

xg_by_minute = xg_by_minute[[team_1, team_2]]

minutes = xg_by_minute.index.to_numpy()

x = np.arange(len(minutes))

width = 0.4


# ===========================================================================================================
# Poisson-binomial
# Sannsynlighet for 0, 1, 2, ... mål
# ===========================================================================================================

def poisson_binomial_distribution(probabilities):

    probabilities = np.asarray(
        probabilities,
        dtype=float
    )

    dist = np.array([1.0])

    for p in probabilities:

        new_dist = np.zeros(
            len(dist) + 1
        )

        new_dist[:-1] += dist * (1 - p)
        new_dist[1:] += dist * p

        dist = new_dist

    return dist


def get_goal_distribution(
    match_df,
    team,
    max_goals=4
):

    probs = match_df.loc[
        match_df["team"] == team,
        "predicted_xg"
    ].to_numpy()

    distribution = poisson_binomial_distribution(
        probs
    )

    exact = np.zeros(
        max_goals + 1
    )

    for k in range(max_goals + 1):

        if k < len(distribution):
            exact[k] = distribution[k]

    cumulative = np.cumsum(exact)

    return exact, cumulative


team_1_exact, team_1_cumulative = get_goal_distribution(
    match,
    team_1,
    max_goals=5
)

team_2_exact, team_2_cumulative = get_goal_distribution(
    match,
    team_2,
    max_goals=5
)


# ===========================================================================================================
# Kampstatistikk
# ===========================================================================================================

predicted_xg_team_1 = match.loc[
    match["team"] == team_1,
    "predicted_xg"
].sum()

predicted_xg_team_2 = match.loc[
    match["team"] == team_2,
    "predicted_xg"
].sum()


actual_goals_team_1 = match.loc[
    (match["team"] == team_1) &
    (match["goal"] == 1),
    "goal"
].sum()

actual_goals_team_2 = match.loc[
    (match["team"] == team_2) &
    (match["goal"] == 1),
    "goal"
].sum()


shots_team_1 = (
    match["team"] == team_1
).sum()

shots_team_2 = (
    match["team"] == team_2
).sum()


statsbomb_xg_team_1 = match.loc[
    match["team"] == team_1,
    "shot_statsbomb_xg"
].sum()

statsbomb_xg_team_2 = match.loc[
    match["team"] == team_2,
    "shot_statsbomb_xg"
].sum()


# ===========================================================================================================
# Figur
# ===========================================================================================================

fig, axes = plt.subplots(
    1,
    2,
    figsize=(16, 7)
)


# ===========================================================================================================
# VENSTRE: Predikert xG per minutt + faktiske mål
# ===========================================================================================================

axes[0].bar(
    x - width / 2,
    xg_by_minute[team_1],
    width,
    label=team_1
)

axes[0].bar(
    x + width / 2,
    xg_by_minute[team_2],
    width,
    label=team_2
)


# ---------------------------------------------------------------------------
# Marker faktiske mål
# ---------------------------------------------------------------------------

goals_by_minute = (
    match[match["goal"] == 1]
    .groupby(["minute", "team"])
    .size()
)


for i, minute in enumerate(minutes):

    for team, offset in [
        (team_1, -width / 2),
        (team_2, width / 2)
    ]:

        number_of_goals = goals_by_minute.get(
            (minute, team),
            0
        )

        if number_of_goals > 0:

            bar_height = xg_by_minute.loc[
                minute,
                team
            ]

            axes[0].scatter(
                i + offset,
                bar_height + 0.02,
                marker="*",
                s=180,
                zorder=5,
                color="g",
                label="Mål" if i == 0 and team == team_1 else None
            )


axes[0].set_xticks(x)

axes[0].set_xticklabels(
    minutes
)

axes[0].set_xlabel(
    "Minutt"
)

axes[0].set_ylabel(
    "Expected Goals"
)

axes[0].set_title(
    "Predikert xG per minutt"
)

axes[0].legend()

axes[0].grid(
    axis="y",
    alpha=0.2
)


# ===========================================================================================================
# HØYRE: Sannsynlighet for antall mål
# ===========================================================================================================

goal_numbers = np.arange(6)

bar_width = 0.35

axes[1].bar(
    goal_numbers - bar_width / 2,
    team_1_exact,
    bar_width,
    label=team_1
)

axes[1].bar(
    goal_numbers + bar_width / 2,
    team_2_exact,
    bar_width,
    label=team_2
)

axes[1].set_xticks(
    goal_numbers
)

axes[1].set_xticklabels(
    ["0", "1", "2", "3", "4", "5"]
)

axes[1].set_ylim(
    0,
    1.0
)

axes[1].set_xlabel(
    "Antall mål"
)

axes[1].set_ylabel(
    "Sannsynlighet"
)

axes[1].set_title(
    "Sannsynlighet for antall mål"
)

axes[1].legend()

axes[1].grid(
    axis="y",
    alpha=0.2
)


# ===========================================================================================================
# INFORMASJONSBOKS
# ===========================================================================================================

match_info = (
    f"{team_1}  {actual_goals_team_1}–{actual_goals_team_2}  {team_2}\n"
    f"Predikert xG:  "
    f"{team_1} {predicted_xg_team_1:.3f}  |  "
    f"{team_2} {predicted_xg_team_2:.3f}\n"
    f"StatsBomb xG:  "
    f"{team_1} {statsbomb_xg_team_1:.3f}  |  "
    f"{team_2} {statsbomb_xg_team_2:.3f}\n"
    f"Skudd:  "
    f"{team_1} {shots_team_1}  |  "
    f"{team_2} {shots_team_2}  |  "
    f"Totalt: {len(match)}"
)

fig.text(
    0.5,
    0.98,
    match_info,
    ha="center",
    va="top",
    fontsize=11,
    bbox=dict(
        boxstyle="round,pad=0.6",
        facecolor="white",
        edgecolor="gray",
        alpha=0.9
    )
)


# ===========================================================================================================
# Hovedtittel
# ===========================================================================================================

fig.suptitle(
    f"Testkamp {selected_match_id}",
    fontsize=15,
    fontweight="bold",
    y=0.86
)


# ===========================================================================================================
# Vis figur
# ===========================================================================================================

plt.tight_layout(
    rect=[0, 0, 1, 0.80]
)

plt.show()

# ===========================================================================================================