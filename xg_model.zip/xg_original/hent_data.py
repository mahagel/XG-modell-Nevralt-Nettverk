import os
os.environ.setdefault("SB_CORES", "4")   # Bruker 4 kjerner for å laste ned data

import pandas as pd
from statsbombpy import sb

import warnings
from statsbombpy.api_client import NoAuthWarning
warnings.filterwarnings("ignore", category=NoAuthWarning) #Fjerner bare warning om at jeg ikke har mer enn gratis tilgang

from config import SHOT_EVENTS_FILE, RELEVANT_LEAGUE_IDS, MIN_YEAR #Henter ut det jeg trenger fra CONFIG

def hent_skudd():
    comps = sb.competitions() #Henter ut alle competitions
    relevant = comps[
        comps.competition_id.isin(RELEVANT_LEAGUE_IDS) #Filtrerer for kun de competitions jeg vil ha
        & (comps.competition_gender == "male") #Og en ekstra sjekk, kun herrefotball
    ].copy()

    relevant["start_year"] = relevant.season_name.str.extract(r"(\d{4})", expand=False).astype(int)
    # Henter ut season_name fra relevant og finner strengen der det er 4 digits på rad
    relevant = relevant[relevant.start_year >= MIN_YEAR] #Henter ut kun ligaer etter mitt start_year

    print(f"{len(relevant)} sesonger å hente") #Printer antall sesonger jeg skal hente

    shot_events = []
    for league in relevant.itertuples():
        print(f"Henter {league.country_name} - {league.competition_name} {league.season_name}")
        # Printer hvilken liga og sesong den jobber med
        try:
            df = sb.competition_events( #Definerer en dataframe med events fra en gitt competiton
                country=league.country_name, #Finner riktig competition
                division=league.competition_name,
                season=league.season_name,
                gender=league.competition_gender,
                filters={"type": "Shot"}, #Filtrerer så jeg kun henter skudd
            )
        except Exception as e: #Hvis jeg får noen feil fra dataen, f.eks at ligaen ikke finnes:
            print(f"  hoppet over ({type(e).__name__}: {e})") #Print hopp over
            continue
        if df.empty:
            continue #Hvis det ikke er noen skudd i en competition, hopp over
        df["competition_id"] = league.competition_id #Lager nye kolonner med bare litt metadata
        df["season_id"] = league.season_id
        df["season_name"] = league.season_name
        shot_events.append(df) #Legger til dataframe for hver liga i en liste med alle events

    return pd.concat(shot_events, ignore_index=True) #Legger alle events inn i samme liste

if __name__ == "__main__": #Når koden kjøres gjør dette: 
    shot_events = hent_skudd()
    shot_events.to_pickle(SHOT_EVENTS_FILE) #Skriver til fil
    print(shot_events.shape) #Printer antall kolonner med rådata og antall datapunkter