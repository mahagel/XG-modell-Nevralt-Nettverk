"""
Delte konstanter for hele xG-pipelinen.
VIKTIG: RANDOM_STATE og TEST_SIZE må være identiske i trenings- og
plotte-scriptet, ellers rekonstruerer xg_plott.py et ANNET testsett enn
det modellen faktisk ble evaluert på. Ved å importere herfra i stedet
for å hardkode tallet flere steder, kan dette ikke lenger skje ved et
uhell.
"""

RELEVANT_LEAGUE_IDS = [2, 7, 9, 11, 12, 16, 35, 43, 55] #Relevante ligaer for dataloaderen
MIN_YEAR = 2011                 # første sesong som tas med (startår)
MATCH_SEED = None               # Hvilken kamp som skal plottes, NONE gir en tilfeldig

RANDOM_STATE = 723              # Velger en tilfeldig state for hvilke datapunkter som skal trenes/valideres/testes
TEST_SIZE = 0.20                # andel av kampene som går til test
VAL_SIZE_OF_REMAINING = 0.125   # 10 % av HELE datasettet (10 / 80 av det som er igjen etter test-splitten)

PENALTY_XG = 0.742              # Gitt ferdig sannsynlighet for straffer
N_EPOCHS = 50                   
LEARNING_RATE = 0.001
BATCH_SIZE = 64
HIDDEN_SIZE = 128               # Hvor mange nevroner er det i hvert skjulte lag
DROPOUT = 0.35                  # Hvor mange prosent av nevronene blir satt til 0, for å unngå overfit
LOSS_FUNCTION = None            # Standard ved NONE er nn.BCEWithLogitsLoss()
LR_PATIENCE = 3                 # Hvor lenge skal den vente før den gjør lr halvparten så stor
EARLY_STOP_PATIENCE = 10        # Hvor lenge skal den vente før den stopper tidlig

SHOT_EVENTS_FILE = "shot_events.pkl"
PREPROCESSED_FILE = "preprossessert_data.pkl"
FEATURE_META_FILE = "feature_meta.pkl"
MODEL_STATE_FILE = "xg_model_state.pt"
SCALER_FILE = "scaler.pkl"