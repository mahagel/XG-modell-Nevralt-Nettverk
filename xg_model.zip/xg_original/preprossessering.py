import pickle

import numpy as np
import pandas as pd

from config import SHOT_EVENTS_FILE, PREPROCESSED_FILE, FEATURE_META_FILE

# ===========================================================================================================
# Henter data:
shot_events = pd.read_pickle(SHOT_EVENTS_FILE)
print(f"Shape for shot_events: {shot_events.shape}")

keep_cols = [ #Hvilke kolonner som inneholder data xg-modellen kan lære fra
    'team', 'match_id', 'location', 'minute',
    'duration', 'period', 'play_pattern', 'position', 'possession',
    'related_events', 'shot_aerial_won', 'shot_body_part',
    'shot_first_time', 'shot_freeze_frame', 'shot_one_on_one', 'shot_open_goal',
    'shot_outcome', 'shot_statsbomb_xg', 'shot_technique', 'shot_type',
    'under_pressure', 'shot_follows_dribble'
]

shot_events = shot_events[keep_cols]  # Lagrer bare kolonnene som inneholder featurene jeg ønsker

mask = shot_events["period"] <= 4 #Fjerner skudd som kommer fra straffekonk
shot_events = shot_events[mask] 
# ===========================================================================================================

# ===========================================================================================================
# Feature bygging:
shot_events["goal"] = (shot_events["shot_outcome"] == "Goal").astype(np.float32)  
# Target er kun mål eller bom, ikke om det ble redning, blokkert eller stang ut osv.


def split_xy(loc):  # Istedenfor x og y posisjon, forteller vinkel og avstand mye mer om sjansen for å score
    if isinstance(loc, list) and len(loc) >= 2: #Hvis vi har xy data og vi har minst x og y, kan inneholde z:
        return pd.Series({"x": loc[0], "y": loc[1]}) #Returner x og y
    return pd.Series({"x": np.nan, "y": np.nan}) #Hvis vi ikke har data returner NAN

xy = shot_events["location"].apply(split_xy) #Legger inn x og y som egne kolonner i shot_events
shot_events = pd.concat([shot_events, xy], axis=1)

shot_events["dist"] = np.hypot(120 - shot_events["x"], 40 - shot_events["y"])
# Finner avstanden ved å finne hypotenusen til en trekant med spisse hjørner i midten av målet og der skuddet tas
shot_events["angle"] = np.abs(
    np.arctan2(44 - shot_events["y"], 120 - shot_events["x"])
    - np.arctan2(36 - shot_events["y"], 120 - shot_events["x"])
)
# Finner vinkelen ved å finne retningen mot en stolpe og retningen mot den andre stolpen og finne differansen

GOAL_X, GOAL_Y1, GOAL_Y2 = 120, 36, 44 #posisjonen til målet, i x=120 og mellom y=36, 44

def _sign(x1, y1, x2, y2, x3, y3): #Finner kryssproduktet mellom p1-p3 og p2-p3
    return (x1 - x3) * (y2 - y3) - (x2 - x3) * (y1 - y3)


def point_in_triangle(px, py, ax, ay, bx, by, cx, cy): 
    # Definerer player posistion px, py, og trekanten mellom skudd og stenger abc
    d1 = _sign(px, py, ax, ay, bx, by) #Sjekker hvilken side av linjen ab spilleren er på
    d2 = _sign(px, py, bx, by, cx, cy) #Sjekker hvilken side av linjen bc spilleren er på
    d3 = _sign(px, py, cx, cy, ax, ay) #Sjekker hvilken side av linjen ac spilleren er på
    has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0) #Så lenge spilleren har samme fortegn på alle tre, er han innenfor
    has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (has_neg and has_pos) #Hvis spilleren både er utafor og innafor return False else return True


def freeze_frame_features(row):  # Finner posisjonen til spillerne mellom skuddet og mål
    ff = row["shot_freeze_frame"] #Henter ut dataen som ligger i freeze frame for et gitt skudd
    sx, sy = row["x"], row["y"] #Henter ut posisjonsdata til skuddet

    feats = { #Egne features: 
        "gk_dist": np.nan, "gk_angle_dev": np.nan, "gk_visible": 0.0, # avstand til keeper, hvor mye av målet keeper dekker
        "n_opp_in_cone": 0.0, "n_team_in_cone": 0.0, #antall mot- og medspillere mellom skudd og mål og hv
        "dist_nearest_opp_in_cone": np.nan, #Hvor langt unna nærmeste motspiller er
    }

    if not isinstance(ff, list) or len(ff) == 0 or pd.isna(sx): #Hvis det ikke er noen data
        return pd.Series(feats) #Returnerer det tomme dictonariet

    shot_angle = np.arctan2(40 - sy, 120 - sx)  #Retning mot midten av mål
    opp_dists_in_cone = [] #Initialiserer
    n_opp_cone = n_team_cone = 0

    for p in ff: #For hver spiller i synsfeltet:
        ploc = p.get("location") #Henter location (x,y)
        if not ploc: #Hvis ingen location data, hopp over spilleren
            continue
        px, py = ploc[0], ploc[1] #Setter x og y som egne variabler
        is_teammate = p.get("teammate", False) #Sjekker om lagkamerat eller ikke
        is_gk = (not is_teammate) and p.get("position", {}).get("name") == "Goalkeeper" #Sjekker om keeper

        if is_gk:
            feats["gk_visible"] = 1.0 #Setter featurene til riktige verdier
            feats["gk_dist"] = np.hypot(sx - px, sy - py) #Avstand er igjen hypotenus til trekanten mellom skuddpos og keeper
            feats["gk_angle_dev"] = np.abs(shot_angle - np.arctan2(py - sy, px - sx)) #Hvor mye av mål keeper dekker
            continue

        in_cone = point_in_triangle(px, py, sx, sy, GOAL_X, GOAL_Y1, GOAL_X, GOAL_Y2)
        # Sjekker om spilleren er mellom skudd og mål

        if is_teammate: #Hvis ja, pluss på en for lagkamerat/motstander
            if in_cone:
                n_team_cone += 1
        else:
            if in_cone:
                n_opp_cone += 1
                opp_dists_in_cone.append(np.hypot(sx - px, sy - py)) #Legg også til avstanden, slik at man kan finne minste avstand

    feats["n_opp_in_cone"] = float(n_opp_cone)
    feats["n_team_in_cone"] = float(n_team_cone)
    feats["dist_nearest_opp_in_cone"] = min(opp_dists_in_cone) if opp_dists_in_cone else np.nan
    #Velger motstander med minste avstand fra skuddpos

    return pd.Series(feats) #Returnerer nye features


ff_feats = shot_events.apply(freeze_frame_features, axis=1) #Finner nye features
shot_events = pd.concat([shot_events, ff_feats], axis=1) #Legger nye features til i datasettet

shot_events.drop(columns=['location', 'x', 'y', 'shot_freeze_frame'], inplace=True) #Fjerner informasjon jeg har brukt for å lage features

cat_cols = ["play_pattern", "shot_body_part", "shot_technique", "shot_type", "period"] #Kategoriske kolonner
shot_events["period"] = shot_events["period"].astype("category") #Gjør om period fra ints til kategori
cat_df = pd.get_dummies(shot_events[cat_cols], dtype=float) #Lager en egen dataframe med kun kategorisk data

bool_cols = [ #Boolean kolonner
    "shot_aerial_won", "shot_first_time", "shot_one_on_one",
    "shot_open_goal", "under_pressure", "shot_follows_dribble",
]
for c in bool_cols: #Gjør om boolean i datasettet til float (1.0/0.0)
    shot_events[c] = shot_events[c].eq(True).astype(float)

num_cols = [ #Numeriske kolonner
    "minute", "duration", "dist", "angle",
    "gk_dist", "gk_angle_dev", "gk_visible",
    "n_opp_in_cone", "n_team_in_cone", "dist_nearest_opp_in_cone",
]

X = pd.concat([shot_events[num_cols], shot_events[bool_cols], cat_df], axis=1)
# Setter sammen alle kollonnene jeg vil ha til X-verdier
X = X.astype(np.float64) #Sørger for at alle er floats
y = shot_events["goal"] #Setter y-verdier til goal (1.0/0.0)
match_id = shot_events["match_id"] #Setter match-id for å ha index, ønsker ikke skudd fra samme kamp i test og train
xg_benchmark = shot_events["shot_statsbomb_xg"] #Lagrer statsbombs egen xg for å sjekke forskjell

# Lagrer hvilke kolonner som er numeriske/boolske/kategoriske, slik at
# trenings- og plotte-scriptet ikke trenger å hardkode disse listene på
# nytt (og risikere at de kommer ut av sync med det som faktisk er i X).
feature_meta = {"num_cols": num_cols, "bool_cols": bool_cols, "cat_cols": cat_cols}
with open(FEATURE_META_FILE, "wb") as f:
    pickle.dump(feature_meta, f) #Lagrer feature meta-verdiene

id_X_y_benchmark = pd.concat([match_id, X, y, xg_benchmark], axis=1)
id_X_y_benchmark.to_pickle(PREPROCESSED_FILE) #Lagrer index, X, y og benchmark som en stor dataframe
print(f"Lagret {PREPROCESSED_FILE}, shape: {id_X_y_benchmark.shape}") #Lagrer til fil