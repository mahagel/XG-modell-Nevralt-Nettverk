import torch
from torch import nn  # nn er neural network

class NeuralNetwork(nn.Module):
    def __init__(self, lr=0.001, n_epochs=20, batch_size=64, input_size=45, dropout = 0.35, #Initialiserer
                 hidden_size=128, output_size=1, loss_fn=None, lr_patience=3, penalty_xg=0.78):
        self.lr = lr
        self.n_epochs = n_epochs
        self.batch_size = batch_size
        self.penalty_xg = penalty_xg

        super().__init__()  # Arver fra Module, bakgrunnsarbeid

        self.linear_relu_stack = nn.Sequential(
            nn.Linear(input_size, hidden_size), #Første skjulte lag
            nn.LayerNorm(hidden_size), #Normaliserer output
            nn.LeakyReLU(),
            nn.Dropout(p=dropout),

            nn.Linear(hidden_size, hidden_size), #Andre skjulte lag
            nn.LayerNorm(hidden_size),
            nn.LeakyReLU(),
            nn.Dropout(p=dropout),

            nn.Linear(hidden_size, hidden_size), #Tredje skjulte lag
            nn.LayerNorm(hidden_size),
            nn.LeakyReLU(),
            nn.Dropout(p=dropout),

            nn.Linear(hidden_size, output_size), #Output lag
        )

        self.loss_fn = loss_fn if loss_fn is not None else nn.BCEWithLogitsLoss()
        #Hvis loss_fn er registrert bruk den, ellers bruk BCE med logitsloss
        self.optimizer = torch.optim.AdamW( #Bruker AdamW som gradiant descent optimizer
            self.parameters(), lr=self.lr, betas=(0.9, 0.999), eps=1e-8, weight_decay=1e-2
        )
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau( 
        # Når man er på et flatt område i parameterlandskapet, halver læringsraten etter noen epoker uten forbedring
            self.optimizer, factor=0.5, patience=lr_patience
        )

    def forward(self, x): #Forward, kjører x tensor gjennom nettverket
        return self.linear_relu_stack(x)

    def predict_proba(self, x, is_penalty=None):
        with torch.no_grad(): #Ikke endre gradientene når du kjører gjennom
            probs = torch.sigmoid(self(x)) #Finner sannsynligheter
            if is_penalty is not None: #Hvis det er straffe
                mask = is_penalty.to(dtype=torch.bool).reshape(-1, 1) #Gjør om til True/False og riktig size
                penalty_value = torch.full_like(probs, self.penalty_xg) #Setter penalty value til riktig size
                probs = torch.where(mask, penalty_value, probs)
                #Hvis mask er true velg bestemt xg verdi, else: velg vanlig prob
            return probs

    def backprop(self, X, y):
        y_pred = self(X) #Prediksjon ved trening (Har filtrert ut straffer fra trening)
        loss = self.loss_fn(y_pred, y) #Henter tap
        loss.backward() #Gjør backprop for å finne gradienter
        self.optimizer.step() #Oppdaterer gradienter med lr
        self.optimizer.zero_grad() #Setter gradienter til 0 igjen
        return loss