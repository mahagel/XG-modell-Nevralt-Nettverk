import pickle

import torch
from torch.utils.data import TensorDataset, DataLoader

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import roc_auc_score, brier_score_loss, log_loss
from sklearn.calibration import calibration_curve

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from model import NeuralNetwork
from config import (
    RANDOM_STATE, TEST_SIZE, VAL_SIZE_OF_REMAINING, 
    PREPROCESSED_FILE, FEATURE_META_FILE, MODEL_STATE_FILE, SCALER_FILE, 
    PENALTY_XG, N_EPOCHS, LEARNING_RATE, BATCH_SIZE, DROPOUT, LOSS_FUNCTION, 
    LR_PATIENCE, HIDDEN_SIZE, EARLY_STOP_PATIENCE
)

# ===========================================================================================================
# Definisjon for early_stopping


class EarlyStopping:
    def __init__(self, patience=3, min_delta=0.0): #initialiserer
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = float('inf')
        self.best_state = None
        self.should_stop = False

    def __call__(self, val_loss, model): #Når den kjører gjennom en verdi gjennom seg selv
        if val_loss < self.best_loss - self.min_delta: #Hvis nåværende loss < beste loss
            self.best_loss = val_loss #Oppdater beste loss
            self.counter = 0 #Early stop counter resatt
            self.best_state = {k: v.clone() for k, v in model.state_dict().items()} #Oppdaterer beste state
        else: #Hvis ikke motsatt
            self.counter += 1 
            if self.counter >= self.patience:
                self.should_stop = True #Hvis loss ikke har forbedret seg innen patience epoker: earlystop
# ===========================================================================================================

# ===========================================================================================================
# Trening, validering og test-funksjoner:

def train_loop(dataloader, model): #Treningsloop
    size = len(dataloader.dataset) #Total størrelse
    model.train() #Setter modellen i treningsmodus
    total_loss = 0
    for batch, (X, y) in enumerate(dataloader): #For hver batch
        loss = model.backprop(X, y) #Finn loss
        total_loss += loss.item() * len(X) #Akkumuler total loss

        if batch % 100 == 0: #For hver 100 batch
            loss, current = loss.item(), batch * model.batch_size + len(X)
            print(f"Loss: {loss:>7f} [{current:>5d} / {size:>5d}]") #Print loss for batchen den er på

    return total_loss / size #returner gjenomsnittlig loss


def val_loop(dataloader, model): #Valideringsloop
    model.eval() #Sett i evalueringsmodus
    num_batches = len(dataloader) #Antall batcher
    val_loss = 0
    with torch.no_grad(): #Ikke rør med gradienter
        for X, y in dataloader: 
            pred = model(X) #Prediksjon
            val_loss += model.loss_fn(pred, y).item() #Akkumulert loss

    val_loss /= num_batches
    print(f"Average validation loss: {val_loss:>8f} \n") #Printer og returnerer gjennomsnittlig loss
    return val_loss


def test_loop(dataloader, model): #Gjør egt. akkurat det samme som eval
    model.eval()
    num_batches = len(dataloader)
    test_loss = 0

    with torch.no_grad():
        for X, y in dataloader:
            pred = model(X)
            test_loss += model.loss_fn(pred, y).item()

    test_loss /= num_batches
    print(f"Avg testing loss: {test_loss:>8f} \n")
# ===========================================================================================================

# ===========================================================================================================
# Data og skalering:
preprossessert = pd.read_pickle(PREPROCESSED_FILE) #Henter data
with open(FEATURE_META_FILE, "rb") as f:
    feature_meta = pickle.load(f)
    
num_cols = feature_meta["num_cols"] #Henter ut de numeriske kolonnene

match_id = preprossessert["match_id"] #Henter ut match-id, y, xg_benchmark og X
y = preprossessert["goal"]
xg_benchmark = preprossessert["shot_statsbomb_xg"]
X = preprossessert.drop(columns=["match_id", "goal", "shot_statsbomb_xg"])

print(f"Shape X (alle skudd, inkl. straffer): {X.shape}")

is_penalty = X.get("shot_type_Penalty", pd.Series(0.0, index=X.index)) == 1.0 #Finner indeksen til skudd med straffe
X, y, match_id, xg_benchmark = (
    X[~is_penalty], y[~is_penalty], match_id[~is_penalty], xg_benchmark[~is_penalty] #Fjerner straffer
)
print(f"Shape X (uten straffer, brukes til trening/evaluering): {X.shape}")

gss_test = GroupShuffleSplit(n_splits=1, test_size=TEST_SIZE, random_state=RANDOM_STATE) #Splitter med 0,2
trainval_idx, test_idx = next(gss_test.split(X, y, groups=match_id)) #Beholder match-id sammen

X_trainval, X_test = X.iloc[trainval_idx].copy(), X.iloc[test_idx].copy() #Lager nye df, med trainval og test
y_trainval, y_test = y.iloc[trainval_idx].copy(), y.iloc[test_idx].copy()
match_id_trainval = match_id.iloc[trainval_idx]

gss_val = GroupShuffleSplit(n_splits=1, test_size=VAL_SIZE_OF_REMAINING, random_state=RANDOM_STATE) #Splitter igjen
train_idx, val_idx = next(gss_val.split(X_trainval, y_trainval, groups=match_id_trainval))

X_train, X_val = X_trainval.iloc[train_idx].copy(), X_trainval.iloc[val_idx].copy() #Lager nye df med train og val
y_train, y_val = y_trainval.iloc[train_idx].copy(), y_trainval.iloc[val_idx].copy()

gk_dist_median = X_train["gk_dist"].median()
gk_angle_median = X_train["gk_angle_dev"].median()
NO_DEFENDER_DIST = 130.0  # større enn lengste mulige avstand på banen

for df_ in (X_train, X_val, X_test):
    df_["gk_dist"] = df_["gk_dist"].fillna(gk_dist_median) #Hvis det er NAN sett inn median
    df_["gk_angle_dev"] = df_["gk_angle_dev"].fillna(gk_angle_median)
    df_["dist_nearest_opp_in_cone"] = df_["dist_nearest_opp_in_cone"].fillna(NO_DEFENDER_DIST) 
    # Hvis det ikke er noen motspiller (utenom keeper) mellom skudd og mål, sett avstanden til maks
    
scaler = StandardScaler() #Bruker standardskalering
X_train.loc[:, num_cols] = scaler.fit_transform(X_train[num_cols]) #Skalerer de numeriske kolonnene
X_val.loc[:, num_cols] = scaler.transform(X_val[num_cols])
X_test.loc[:, num_cols] = scaler.transform(X_test[num_cols])

# Lagrer scaler + imputeringsverdier sammen, slik at xg_plott.py (og enhver
# annen fremtidig fil) kan transformere nye data PÅ NØYAKTIG SAMME MÅTE
# uten å måtte fitte på nytt eller gjette medianverdiene.
joblib.dump(
    {
        "scaler": scaler,
        "gk_dist_median": gk_dist_median,
        "gk_angle_median": gk_angle_median,
        "no_defender_dist": NO_DEFENDER_DIST,
    },
    SCALER_FILE,
)

def to_tensor_dataset(X_df, y_series): #Gjør om fra dataframe til tensor
    X_t = torch.tensor(X_df.to_numpy(dtype=np.float32))
    y_t = torch.tensor(y_series.to_numpy(dtype=np.float32)).unsqueeze(1)
    return TensorDataset(X_t, y_t) 

#Gjør om fra dataframe til dataloader med riktig batch-size
train_dataloader = DataLoader(to_tensor_dataset(X_train, y_train), batch_size=BATCH_SIZE, shuffle=True)
val_dataloader = DataLoader(to_tensor_dataset(X_val, y_val), batch_size=BATCH_SIZE)
test_dataloader = DataLoader(to_tensor_dataset(X_test, y_test), batch_size=BATCH_SIZE)
# ===========================================================================================================

# ===========================================================================================================
# Initialisering:
xg_model = NeuralNetwork(
    lr=LEARNING_RATE, n_epochs=N_EPOCHS, batch_size=BATCH_SIZE, input_size=X.shape[1], output_size=1, 
    hidden_size=HIDDEN_SIZE, penalty_xg=PENALTY_XG, dropout=DROPOUT, lr_patience=LR_PATIENCE, loss_fn=LOSS_FUNCTION
)
EarlyStop = EarlyStopping(patience=EARLY_STOP_PATIENCE, min_delta=0.001)

train_loss_history = []
val_loss_history = []
epoch_history = []
# ===========================================================================================================

# ===========================================================================================================
# Trening:
for epoch in range(xg_model.n_epochs):
    print(f"Epoch {epoch+1}\n--------------------------------")
    train_loss = train_loop(train_dataloader, xg_model)
    val_loss = val_loop(val_dataloader, xg_model)
    xg_model.scheduler.step(val_loss)

    train_loss_history.append(train_loss)
    val_loss_history.append(val_loss)
    epoch_history.append(epoch)

    EarlyStop(val_loss, xg_model)
    if EarlyStop.should_stop:
        print(f"Stopped early at epoch: {epoch + 1} \n")
        break

xg_model.load_state_dict(EarlyStop.best_state)

# Lagrer de TRENTE vektene til disk
torch.save(xg_model.state_dict(), MODEL_STATE_FILE)
print(f"Lagret trente vekter til {MODEL_STATE_FILE}")
# ===========================================================================================================

# ===========================================================================================================
# Testing:
test_loop(test_dataloader, xg_model)
print("Done! \n\n")

xg_model.eval() #Setter modellen i evalueringsmodus
with torch.no_grad():
    X_test_t = torch.tensor(X_test.to_numpy(dtype=np.float32)) #Gjør testdata til tensor
    p_test = torch.sigmoid(xg_model(X_test_t)).numpy().flatten() 
    # Kjører testdata igjennom modellen for å få ut predictions

print(f"Log loss:    {log_loss(y_test, p_test):.4f}") #Finner log loss for predictions vs faktisk data
print(f"Brier score: {brier_score_loss(y_test, p_test):.4f}") #Finner brier score loss
print(f"ROC AUC:     {roc_auc_score(y_test, p_test):.4f}") #Finner ROC AUC score

xg_sb = xg_benchmark.loc[y_test.index] #Gjør samme greia for statsbomb sin xg modell
print(f"\nStatsBomb xG — Log loss:    {log_loss(y_test, xg_sb):.4f}")
print(f"StatsBomb xG — Brier score: {brier_score_loss(y_test, xg_sb):.4f}")
print(f"StatsBomb xG — ROC AUC:     {roc_auc_score(y_test, xg_sb):.4f}")

print(f"\nDin modell — sum xG: {p_test.sum():.1f}, faktiske mål: {y_test.sum():.0f}")
print(f"StatsBomb  — sum xG: {xg_sb.sum():.1f}, faktiske mål: {y_test.sum():.0f}") 
# Sjekker at resultatene gir mening
# ===========================================================================================================

# ===========================================================================================================
# Kalibreringsplott + Loss-historikk i samme figur

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# --- Kalibreringsplott ---
prob_true, prob_pred = calibration_curve(
    y_test, p_test, n_bins=10, strategy="quantile"
)
prob_true_sb, prob_pred_sb = calibration_curve(
    y_test, xg_sb, n_bins=10, strategy="quantile"
)

axes[0].plot(prob_pred, prob_true, marker="o", label="Din modell")
axes[0].plot(prob_pred_sb, prob_true_sb, marker="s", label="StatsBomb xG")
axes[0].plot(
    [0, 1], [0, 1],
    linestyle="--",
    color="gray",
    label="Perfekt kalibrert"
)

axes[0].set_xlabel("Predikert sannsynlighet")
axes[0].set_ylabel("Observert målfrekvens")
axes[0].set_title("Kalibrering")
axes[0].legend()

# --- Loss-historikk ---
axes[1].plot(epoch_history, train_loss_history, label="Training loss")
axes[1].plot(epoch_history, val_loss_history, label="Eval loss")

axes[1].set_title("xG-modell loss history")
axes[1].set_xlabel("Epochs")
axes[1].set_ylabel("Loss")
axes[1].legend()

# Justerer layout
plt.tight_layout()
plt.show()

# ===========================================================================================================